###################################################
##
##                 Partie I
##   Analyse Empirique et Exploratoire  des Données
##
## 1- Récupération & lecture des données
## 2- Exploration des données
## 3- Extraction des données pour une station
## 4- Trace les données pour cette station
##
## 
####################################################

## récupération des données ici : https://meteo.data.gouv.fr/

getwd() ## où suis-je ?
##### I1- Lecture des données brutes #########
mydata <- read.csv("Q_21_previous-1950-2024_RR-T-Vent.csv.gz", sep = ";")


###########################################################
    
    ## I2- Exploration des données
##########################################################
class(mydata) ## Classe de l'objet
str(mydata) ## structure de l'objet avec le type des données contenues
head(mydata) ## affichage les premières lignes des données
tail(mydata) ## affichage des dernières lignes des données
dim(mydata) ## dimension de l'objet
    
    ## Pour savoir à quoi correspondent les colonnes il faut récupérer sur le site
    ## le fichier de description des champs qui se nomme "Q_descriptif_champs_RR-T-Vent.csv"

###########################################################
MFpostes <- unique(mydata[, c("NUM_POSTE", "NOM_USUEL", "LAT", "LON", "ALTI")])
head(MFpostes) ## Affichage des premières lignes des données
dim(MFpostes)

##########################################################
##
## Questions : combien de stations ?
##             comment ferriez-vous pour créer une carte
##             à partir des données de l'objet MFposte ?
##
#########################################################



## Nettoyage des données i.e. suppression/conservation des certaines colonnes
## pour cela on s'aide du fichier "Q_descriptif_champs_RR-T-Vent.csv"
## récupéré sur le site https://meteo.data.gouv.fr/

mydata <- mydata[,c("NUM_POSTE","AAAAMMJJ","RR","TN","TX","TM","FXI")]

##########################################################
## I3- Extraction des données d'une station de Dijon

## Recherche le/les stations dont DIJON est dans le nom usuel

MFpostes[grepl("DIJON", MFpostes$NOM_USUEL),]

## Nous allons récupérer les données d'une des stations DIJON à partir de son numéro
## de poste NUM_POSTE, le numéro de poste est celui de DIJON-LONGVIC

mydata.st <- subset(mydata, mydata$NUM_POSTE == 21473001)
dim(mydata.st)
head(mydata.st)
tail(mydata.st)

######################################################################
##
## Question : est ce que la dimension de mydata.st est cohérente
##            avec le nombre de jours de la période d'enregistrement ?
##
######################################################################

######################################################################
# récupération des données pour cette station enregistrées depuis 2025
#####################################################################

mydata2.st <- read.csv("Q_21_latest-2025-2026_RR-T-Vent.csv.gz", sep = ";")
mydata2.st <- mydata2.st[,c("NUM_POSTE","AAAAMMJJ","RR","TN","TX","TM","FXI")]

### extraction des données de DIJON-LONGVIC pour la période 2025-2026 & concaténation
## avec des données de cette station de la période 1950-2024

## Avant de concaténer, vérifier que les données de mydata2.st commence bien le 1/01/2025

mydata.st <- rbind(mydata.st,subset(mydata2.st, mydata2.st$NUM_POSTE == 21473001))

##########################################################
## I4- Trace les températures minimales
## pdf(file="Station.pdf")
plot(mydata.st$TN,
  type = "l", xlab = "Temps (jours)", ylab = "Tn (degrés Celsius)",
  main = "Station Météo-France Dijon"
)
## dev.off()
## Ajout des températures maximales sur le graphes
## lines(mydata.st$TX,col="red")

##########################################################
##########################################################
##  Calcul des moyennes annuelles
##  1- à partir de fonctions de base et d'une boucle
##  2- à partir d'un objet série temporelle
##   package utilisé : xts
##########################################################

##########################################################################
## 1.- Calcul à partir d'une boucle for
###########################################################################

### Création d'une vecteur contenant les années d'enregistrement climatique
## à partie du champ (colonne) qui contient les dates

yoi <- substr(mydata.st$AAAAMMJJ, 1, 4)

## Ajout dans l'objet mydata.st

mydata.st$Year <- yoi

annees <- unique(mydata.st$Year)

## Bloucle pour le calcul de la moyenne annuelle
## ci-dessous pour les TN
resu <-c()
for(i in annees){
    #print(i)
    tmp <- subset(mydata.st$TN, mydata.st$Year==i) ##extrait l'année i
    print(mean(tmp)) ## Affiche la valeur de la moyenne pour l'année i
    resu <- c(resu,mean(tmp, na.rm=TRUE)) ## rempli l'objet resu
}
## faire également pour les températures maximales
class(resu)
length(resu)

###################################################################
## Tracer l'évolution de la moyenne annuel des TN puis pour les TX
## et les pluies RR. Attention pour les pluies on calcule le cumul 
## annuel i.e. la somme des précipitations il faut remplacer la fonction mean
## par sum dans la boucle

###############################################################################
##################################################################
## 2.- Calcul à partir de la création d'un objet série temporelle
##     utilisation du package xts
##################################################################

str(mydata.st) ## format des colonnes

################################################################
## transformation du champ qui contient les dates au format texte
## non reconnues comme du 'temps' en un vecteur de dates 
mydates <- as.Date(as.character(mydata.st$AAAAMMJJ), "%Y%m%d")
str(mydates)
class(mydates)

#################################################################
## Création de l'objet séries temporelles xts pour Tn, Tx et RR
## et pour la première station
library(xts)

myxts.st <- xts(mydata.st[, c("TN", "TX", "TM", "RR", "FXI")], order.by = mydates)
class(myxts.st)
str(myxts.st)
tail(myxts.st)

#################################################################
## Les données sont elles complètes i.e. y aurait-il des données manquantes ?

myxts.st[!complete.cases(myxts.st), ]

# myxts.stnx <- na.omit(myxts.st) ## supprime les NA pour les Tn et les Tx
## Calcul des moyennes annuelles pour Tn, Tx, Tm et FXI
Tnx.year <- apply.yearly(myxts.st[, c("TN", "TX", "TM", "FXI")],
                         FUN=function(x) colMeans(x,na.rm = TRUE))

##################################################################
## Comparaison entre les deux méthodes
head(as.numeric(Tnx.year$TN))
head(resu)

##################################################################
## Trace l'évolution inter-annuelle des Tn et des Tx
plot(Tnx.year)

##################################################################
## Calcul des cumuls annuels pour les précipitations
RR.year <- apply.yearly(myxts.st[,"RR"],
                        FUN=function(x) sum(x, na.rm = TRUE) ) 
plot(RR.year)
## Passe d'un objet xts à un objet dataframe
hist(RR.year$RR, breaks = 15)
#mydf <- as.data.frame(Tnx.year)
#head(mydf)

##################################################################
####################################################
##
## Partie II : analyse de séries
##
## 1- détection de rupture (test de Pettitt)
## 2- détection de tendance (test de Mann-Kendall)
##
## programmation R + package : trend
#####################################################

## transforme l'objet Tnx.year en un dataframe
mydf <- as.data.frame(Tnx.year["1950/2025"])

##################################
## Code R :  test de petitt cf. doc pdf 
## v <- matrix(0,nrow(mydf),1)
## u <- matrix(0,nrow(mydf),1)
## (mydf)

## #######################################################
## ## Initialisation
## for(j in 1:nrow(v)) v[1,1] <- v[1,1]+sign(mydf[1,2]-mydf[j,2])
## u[1] <- v[1]
## u[1]

## ########################################################
## ## Calcule de la statistique (Ut,T) non-parametrique du test de Pettitt
## for(t in 2:nrow(v)){
##     for(j in 1:nrow(v)) v[t,1] <- v[t,1]+sign(mydf[t,2]-mydf[j,2])
##     u[t,1] <- u[t-1,1]+v[t,1]
## }

## (kt <- max(abs(u)))
## ## rang 
## (which.max(abs(u)))

## ########################################################
## ## seuil de significativité pour Kt 
## n <- nrow(mydf)
## poa <- 2*exp(-6*kt^2/(n^3+n^2))
## poa
## ## seuil théorique à 95%
## uc95=sqrt((n^3+n^2)*log(0.05)/(-6))  ## val critique val abs u(t)>uc;
## ## seuil theorique à 99%
## uc99=sqrt((n^3+n^2)*log(0.01)/(-6)) ## val critique val abs u(t)>uc;
## uc95;uc99

## ########################################################
## ## Trace les résultats du test
## myears <- as.integer(substr(row.names(mydf),1,4))
## plot(myears,mydf$TX, type="l", col="blue")

## plot(myears,u/1000, type="l", col="black")
## abline(h=-uc95/1000,col='blue',xlim=c(1960,2015))
## abline(h=-uc99/1000,col='red',xlim=c(1960,2015))

#########################################################
#######################################################
## Vérification pour le test de rupture
## comparer avec les résultats obtenus précédemment
## utilisation du package trend

library(trend)

ptest <- pettitt.test(mydf[,"TX"])
(ptest)
annees[ptest$estimate]

#######################################################
################################################
## test de tendance
mk.test(mydf[,"TX"])
## les test nous indique s'il y a présence ou absence de tendance
## et le signe de la tendance mais ne nous dit rien sur le type de tendance
## linéaire, non-linéaire, par blocs etc.
##
################################################
## Trace la tendance linéaire
myears <- as.integer(substr(row.names(mydf),1,4))
plot(myears,mydf[,"TX"], type="l", col="blue")
trend.l <- lm(mydf[,"TX"]~myears)
abline(trend.l,col="red")
## trend.nl <- lm(mydf[,"TN"] ~ myears + I(myears^2))
## ## Trace la tendance non-linéaire
## lines(myears,predict(trend.nl),col="black")

#########################################################"
#######################################################
##
## Test par fenêtre glissante
## SMWDA : Split Moving Windows Dissimilarity Analysis
##
#######################################################

source("smwda.R")

## taille de la fenêtre
ws <- c(4,8,12,16)
resu <- c()
## Boucle sur les différentes fenêtres
for(j in seq(along=ws)){
    ## calcul de la métrique i.e. distance euclidienne
    rtmp <- smwda(M=mydf[,"TX"],Q=ws[j])
    ## complète les valeur manquantes début et fin de série
    ## en fonction de la taille de la fenêtre
    rtmp <- c(rep(0,(ws[j]/2)-1),rtmp,rep(0,(ws[j]/2)))
    resu <- cbind(resu,rtmp)
}

## Calcul du seuil théorique de signification pour 5% et 1%
resu.test <- monte.smwda(M=mydf[,"TX"],lws=ws,rn=1000)

plot(myears,resu[,3], type="l", col="blue")
abline(h=resu.test[3,1],col='green',xlim=c(1950,2022))
abline(h=resu.test[3,2],col='red',xlim=c(1950,2022))

######################################################
resu.test

###################################################################
#########################################################
##
##                   Travaux à faire :
##  - refaire pour les Tn, Tx,  RR et FXI pour d'autres stations
##  - que déduire de l'ensemble de ces résultats ?
##
##########################################################
####################################################################


## ## Au pas de temps saisonnier
## ## 
## myxts.seas <- myxts.st["1950-03-01/2022-11-30"]
## # Calcul de fin de période trimestrielle en partant du 1er mars (MAM, JJA,SON, DJF)
## ep <- endpoints(myxts.seas, on = "months", k = 3)

## # Calcul de la moyenne saisonnière
## Tseasons <- period.apply(myxts.seas[,c("TN","TX")], INDEX = ep,
##                          FUN = function(x) mean(x, na.rm = TRUE))

## (.indexmon(Tseasons))
## MAM <- Tseasons[which(.indexmon(Tseasons)==4),]

## ## Créer les objets pour les autres saisons
## ## faires les tests de rupture et tendance pour les saisons
## ## Rupture sur les saisons ?
## ## Quelle est la saisonnalité du rechauffement climatique ?

