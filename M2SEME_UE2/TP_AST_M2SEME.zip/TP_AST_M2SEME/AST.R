###################################################
##
##                 Partie I
##   Analyse Empirique et Exploratoire  des Données
##
## 1- Lecture des données
## 2- Exploration des données
## 3- Extraction des données pour la première station
## 4- Trace les données pour cette station
##
## Thierry Castel , dernières modifications 2020
####################################################

##### I1- Lecture des données brutes #########
mydata <- read.csv("MFdata.csv")
postesMF <- read.csv("MFpostes.csv")

class(postesMF) ## Classe de l'objet

##########################################################
tail(mydata)  ## affichage des dernières lignes des données

###########################################################

## I2- Exploration des données
dim(mydata) ## dimension de l'objet
class(mydata) ## classe de l'objet
str(postesMF) ## structure de l'objet avec le type des données contenues

###########################################################
head(mydata) ## Affichage des premières lignes des données

###########################################################

## Suppression de la première colonne
mydata <- mydata[,-1]
head(mydata)

##########################################################
## Combien de stations ?
nbrst <- unique(mydata$NumPoste)
length(nbrst)
nbrst

##########################################################
## I3- Extraction des données de la première station
mydata.st <- subset(mydata,mydata$NumPoste==nbrst[9])
dim(mydata.st)
head(mydata.st)
tail(mydata.st)

##########################################################
## I4- Trace les températures minimales
##pdf(file="Station.pdf")
plot(mydata.st$Tn,type="l", xlab="Temps (jours)",ylab="Tn (degrés Celsius)",
     main="Station Météo-France 21473001")
##dev.off()
## Ajout des températures maximales sur le graphes
## lines(mydata.st$Tx,col="red")

##########################################################
##########################################################
##  Calcul des moyennes annuelles 
##  1- à partir de fonctions de base et d'une boucle 
##  2- à partir d'un objet série temporelle
##   package utilisé : xts
##########################################################

annees <- unique(mydata$Year)
resu <-c()
for(i in annees){
    #print(i)
    tmp <- subset(mydata.st$Tn, mydata.st$Year==i) ##extrait l'année i
    print(mean(tmp)) ## Affiche la valeur de la moyenne pour l'année i
    resu <- c(resu,mean(tmp, na.rm=TRUE)) ## rempli l'objet resu
}
## faire pour les températures maximales
class(resu)
length(resu)

################################################################
## création d'un vecteur avec les dates au format texte
mydates <- paste(mydata.st$Year,"-",mydata.st$Month,"-",mydata.st$Day,
                 sep="")
str(mydates)

################################################################
class(mydates)
str(mydates)

################################################################
## transformation de ce vecteur de texte en un vecteur de dates
mydates <- as.Date(mydates,"%Y-%m-%d")
str(mydates)
class(mydates)

#################################################################
## Création de l'objet séries temporelles xts pour Tn, Tx et RR
## et pour la première station
library(xts)
myxts.st <- xts(mydata.st[,c("Tn","Tx","RR")], order.by=mydates)
class(myxts.st)
str(myxts.st)
tail(myxts.st)

#################################################################
myxts.stnx <- na.omit(myxts.st[,1:2]) ## supprime les NA pour les Tn et les Tx
## Calcul des moyennes annuelles pour Tn et Tx
Tnx.year <- apply.yearly(myxts.stnx, mean)
##tail(Tnx.year)
tail(myxts.stnx)

##################################################################
## Comparaison entre les deux méthodes
head(as.numeric(Tnx.year$Tn))
head(resu)

##################################################################
## Trace l'évolution inter-annuelle des Tn et des Tx
plot(Tnx.year)

##################################################################
## Calcul des cumuls annuels pour les précipitations
RR.year <- apply.yearly(myxts.st[,3], sum) 
plot(RR.year)
## Passe d'un objet xts à un objet dataframe
hist(RR.year$RR, breaks = 15)
#mydf <- as.data.frame(Tnx.year)
#head(mydf)

##################################################################
####################################################
##
## Partie II : analyse de séries
##
## 1- détection de rupture (test de Pettitt)
## 2- détection de tendance (test de Mann-Kendall)
##
## programmation R + package : trend
#####################################################

mydf <- as.data.frame(Tnx.year)
v <- matrix(0,nrow(mydf),1)
u <- matrix(0,nrow(mydf),1)
(mydf)

#######################################################
## Initialisation
for(j in 1:nrow(v)) v[1,1] <- v[1,1]+sign(mydf[1,2]-mydf[j,2])
u[1] <- v[1]
u[1]

########################################################
## Calcule de la statistique (Ut,T) non-parametrique du test de Pettitt
for(t in 2:nrow(v)){
    for(j in 1:nrow(v)) v[t,1] <- v[t,1]+sign(mydf[t,2]-mydf[j,2])
    u[t,1] <- u[t-1,1]+v[t,1]
}

(kt <- max(abs(u)))
## rang 
(which.max(abs(u)))

########################################################
## seuil de significativité pour Kt 
n <- nrow(mydf)
poa <- 2*exp(-6*kt^2/(n^3+n^2))
poa
## seuil théorique à 95%
uc95=sqrt((n^3+n^2)*log(0.05)/(-6))  ## val critique val abs u(t)>uc;
## seuil theorique à 99%
uc99=sqrt((n^3+n^2)*log(0.01)/(-6)) ## val critique val abs u(t)>uc;
uc95;uc99

########################################################
## Trace les résultats du test
myears <- as.integer(substr(row.names(mydf),1,4))
plot(myears,mydf$Tx, type="l", col="blue")

plot(myears,u/1000, type="l", col="black")
abline(h=-uc95/1000,col='blue',xlim=c(1960,2015))
abline(h=-uc99/1000,col='red',xlim=c(1960,2015))

#########################################################
#######################################################
## Vérification pour le test de rupture
## comparer avec les résultats obtenus précédemment
## utilisation du package trend

library(trend)

ptest <- pettitt.test(mydf[,2])
(ptest)
annees[ptest$estimate]

#######################################################
################################################
## test de tendance
mk.test(mydf[,2])
## les test nous indique s'il y a présence ou absence de tendance
## et le signe de la tendance mais ne nous dit rien sur le type de tendance
## linéaire, non-linéaire, par blocs etc.
##
################################################
## Trace la tendance linéaire
plot(myears,mydf[,1], type="l", col="blue")
trend.l <- lm(mydf[,1]~myears)
abline(trend.l,col="red")
trend.nl <- lm(mydf[,1] ~ myears + I(myears^2))
## Trace la tendance non-linéaire
lines(myears,predict(trend.nl),col="black")

#########################################################"
#######################################################
##
## Test par fenêtre glissante
## SMWDA : Split Moving Windows Dissimilarity Analysis
##
#######################################################

source("smwda.R")

## taille de la fenêtre
ws <- c(4,8,12,16)
resu <- c()
## Boucle sur les différentes fenêtres
for(j in seq(along=ws)){
    ## calcul de la métrique i.e. distance euclidienne
    rtmp <- smwda(M=mydf[,2],Q=ws[j])
    ## complète les valeur manquantes début et fin de série
    ## en fonction de la taille de la fenêtre
    rtmp <- c(rep(0,(ws[j]/2)-1),rtmp,rep(0,(ws[j]/2)))
    resu <- cbind(resu,rtmp)
}

## Calcul du seuil théorique de signification pour 5% et 1%
resu.test <- monte.smwda(M=mydf[,1],lws=ws,rn=1000)

plot(myears,resu[,4], type="l", col="blue")
abline(h=resu.test[4,1],col='green',xlim=c(1960,2015))
abline(h=resu.test[4,2],col='red',xlim=c(1960,2015))

######################################################
resu.test



#########################################################
##
##                   Travaux à faire :
##  - refaire pour les Tn, Tx et RR et pour toutes les stations
##  - que déduire de l'ensemble de ces résultats ?
##
##########################################################

## Au pas de temps saisonnier
## 
myxts.seas <- myxts.st["1961-03-01/2015-11-30"]
# Calcul de fin de période trimestrielle en partant du 1er mars (MAM, JJA,SON, DJF)
ep <- endpoints(myxts.seas, on = "months", k = 3)

# Calcul de la moyenne saisonnière
Tseasons <- period.apply(myxts.seas[,c("Tn","Tx")], INDEX = ep, FUN = mean)

(.indexmon(Tseasons))
MAM <- Tseasons[which(.indexmon(Tseasons)==4),]

## Créer les objets pour les autres saisons
## faires les tests de rupture et tendance pour les saisons
## Rupture sur les saisons ?
## Quelle est la saisonnalité du rechauffement climatique ?

