
smwda <- function(M,Q){
    ## M série brute ou normalisée
    ## Q taille de la fenêtre
    N <- length(M)
    D <- c()
    for(i in  seq(Q/2,N-Q/2,by=1)){
        S1 <- M[((i-Q/2)+1):i]
        S2 <- M[(i+1):(i+Q/2)]
        S1 <- mean(S1)
        S2 <- mean(S2)
        ##print((S1-S2)^2)
        D <- c(D,ifelse(is.nan((S1-S2)^2),NA,sqrt((S1-S2)^2)))
    }

    return(D)
}

monte.smwda <- function(M,lws,rn=1000){
    ## M = série brute ou normalisée
    ## lws = liste des fenêtres

    ## Calcul de l'autocorrélation
    autocor <- cor(M[1:(length(M)-1)],M[(2:length(M))])
    rn <- rn ## nombre de série simulée pour le test
    xx <- matrix(0,length(M),rn)
    stest <- c()

    for(k in seq(along=lws)){
        l <- lws[k]
        xx[1,] <- rnorm(rn)
        for(j in 2:length(M)){
            xx[j,]=autocor*xx[(j-1),]+(1-autocor)*rnorm(rn)
        }
        ## standardise si series normalisées
        ## yy <- t(scale(t(xx)))
        yy <- xx
        dyy <- dim(yy)
        r <- matrix(0,dyy[1],dyy[2])
        for(d in (((l/2)+1):(dyy[1]-(l/2)+1))){
            d1 <- apply(yy[(d-(l/2)):(d-1),],2,mean)
            d2 <- apply(yy[d:(d+(l/2)-1),],2,mean)
            ds <- sqrt((d1-d2)^2)
            r[d,] <- ds
        }
        r <- t(r)
        rs <- apply(r, 2, sort)

        test95 <- mean(rs[floor(0.95*rn),(((l/2)+1):(dyy[1]-(l/2)+1))])
        test99 <- mean(rs[floor(0.99*rn),(((l/2)+1):(dyy[1]-(l/2)+1))])

        stest <- rbind(stest,cbind(test95,test99))
    }
    
    return(stest)
}
